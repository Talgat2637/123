import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean isDoorOpen = false;
        boolean isKeyFound = false;
        boolean isPuzzleSolved = false;

        System.out.println("Вы просыпаетесь в комнате. Введите ваше имя:");
        String playerName = scanner.nextLine();

        while (!isDoorOpen) {
            System.out.println("\nВы можете:");
            System.out.println("1. Открыть дверь");
            System.out.println("2. Заглянуть под кровать");
            System.out.println("3. Открыть ящик в углу комнаты");
            System.out.println("4. Открыть вентиляцию");
            System.out.println("5. Взглянуть на тумбочку");
            System.out.println("6. Взглянуть на статую рядом с дверью");
            System.out.print("Выберите действие: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Очистка буфера

            switch (choice) {
                case 1:
                    if (isKeyFound) {
                        System.out.println(playerName + ", вы успешно сбежали!");
                        isDoorOpen = true;
                    } else {
                        System.out.println("Дверь заперта. Вам нужна отмычка.");
                    }
                    break;
                case 2:
                    if (!isPuzzleSolved) {
                        System.out.println(playerName + ", вы нашли первый артефакт.");
                        isPuzzleSolved = true;
                    } else {
                        System.out.println("Артефакт уже был найден.");
                    }
                    break;
                case 3:
                    if (!isKeyFound) {
                        System.out.println(playerName + ", вы нашли ключ от ящика.");
                        isKeyFound = true;
                    } else {
                        System.out.println("Ключ уже был найден.");
                    }
                    break;
                case 4:
                    if (!isPuzzleSolved) {
                        System.out.println("Вентиляция требует попытки открыть ее три раза.");
                        isPuzzleSolved = true;
                    } else {
                        System.out.println("Вентиляция уже была открыта.");
                    }
                    break;
                case 5:
                    if (!isPuzzleSolved) {
                        System.out.println(playerName + ", вы нашли второй артефакт.");
                        isPuzzleSolved = true;
                    } else {
                        System.out.println("Артефакт уже был найден.");
                    }
                    break;
                case 6:
                    if (isPuzzleSolved && isKeyFound) {
                        System.out.println(playerName + ", вы активировали статую и получили отмычку.");
                        isDoorOpen = true;
                    } else {
                        System.out.println("Статуя требует активации с помощью трех артефактов.");
                    }
                    break;
                default:
                    System.out.println("Неверный выбор. Попробуйте снова.");
            }
        }

        scanner.close();
    }
}
